//Skye Hewitt
//sbhngh@mail.umkc.edu
//Program 7
//05-12-19
//Taking a file of ratings and restaurants, and finding the average rating for each restaurant. 

#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include <vector>
#include <iomanip>
#include <iterator>

using namespace std;

void addRestaurant(vector<vector<int>> &restaurantRating, vector<string> &restaurantList, string newRestaurant)
{
	//Adds restaurant to the restaurant vector, and its rating(s) are put into a two-dimensional vector at the same index. 
	restaurantList.push_back(newRestaurant);
	restaurantRating.resize(restaurantRating.size() + 1);
}

int getIndex(vector<string> restaurantList, string newRestaurant)
{
	//Returns the index of the restaurant. This index aligns with the index in the rating vector.
	for (int index = 0; index < restaurantList.size(); ++index)
	{
		if (restaurantList.at(index) == newRestaurant)
			return index;
	}
	return -1; //Not found, returns an error
}

void addRating(vector<vector<int>> &restaurantRating, int newRating, int index)
{
	//Adds the rating to at the index of the corresponding restaurant found in the restaurant vector.
	restaurantRating.at(index).push_back(newRating);
}

void averageRatings(map<string, double> &restaurantAvgRating, vector<vector<int>> restaurantRating, string newRestaurant, int index)
{
	//The ratings from the two dimensional rating vector are added together and emplaced into a map with the restaurant with the same
	//index as the rating(s).
	double avgRating = 0.0;
	for (int i = 0; i < restaurantRating.at(index).size(); ++i)
	{
		avgRating += restaurantRating.at(index).at(i);
	}
	avgRating /= restaurantRating.at(index).size();
	restaurantAvgRating.emplace(newRestaurant, avgRating);
}

void printRatings(map<string, double> restaurantAvgRating, int restaurantCount, vector<vector<int>> restaurantRatings)
{
	//Iterate through the Average Restaurant Rating map and prints out the restaurant name and the average review. 
	int index = 0;
	for (const auto& newRestaurant : restaurantAvgRating)
	{
		cout << left << setw(13);
		cout << newRestaurant.first << " : " << restaurantRatings.at(index).size() << " Reviewers.  Average of " << newRestaurant.second << "/5" << endl;
		++index;
	}
}

int main() 
{
	ifstream inRatings("ratings.txt");
	map<string, double> restaurantAvgRating;
	vector<vector<int>> restaurantRating; //The first set of indexes of the vector is a set of vectors with a corresponding restaurant
	vector<string> restaurantList;
	int newRating, restaurantNum, index, restaurantCount = 0;
	string newRestaurant;


	inRatings >> restaurantNum; //How many restaurants reviews total 
	inRatings.ignore(); //Ignoring whitespace

	while (inRatings.good()) //While not end of file, not bad, etc. 
	{
		
		getline(inRatings, newRestaurant); //Using getline as oppose to >> because some restaurant names are multiple words
		inRatings >> newRating;
		inRatings.ignore(); //Ignoring whitespace following rating

		if (find(restaurantList.begin(), restaurantList.end(), newRestaurant) == restaurantList.end())
			//If the restaurant is not in the restaurant vector. (.find() returns container.end() if the element is not found.) 
		{
			addRestaurant(restaurantRating, restaurantList, newRestaurant);
			++restaurantCount;
		}

		index = getIndex(restaurantList, newRestaurant);
		addRating(restaurantRating, newRating, index);
	}

	for (index = 0; index < restaurantCount; ++index)
		//Iterate through the restaurant names and their corresponding rating(s), average them out and put them in a map to be printed later. 
	{
		newRestaurant = restaurantList.at(index);
		averageRatings(restaurantAvgRating, restaurantRating, newRestaurant, index);
	}
	//Print out all restaurant ratings. 
	printRatings(restaurantAvgRating, restaurantCount, restaurantRating);

	system("pause");
}